<?php
$user="root";
$pass="";
$db="randikhana";
$link=mysql_connect('localhost',$user,$pass);
if(!$link)
die("unable to open database");
mysql_select_db($db) OR die("unable to open file");


$email=$_POST['nlemail'];
$pen="SELECT * FROM chatandfeedback WHERE subscribedemail='$email' ";
$result=mysql_query($pen);

if($result)
{

if(mysql_num_rows($result)==0)


{
$pen=mysql_query("Insert into chatandfeedback(subscribedemail)values('$email')" ) or die("insert error");
header("location:bookservices.php");
}
else 
{
echo"<script>
window.open('about.html');
</script>";
echo "Already subscribed email";
}
}
else

echo "query failed";
?>