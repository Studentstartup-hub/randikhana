<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&display=swap" rel="stylesheet">
<title></title>
	<style>
		
			

		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			
			background-color:  white;
		font-family: 'Josefin Sans', sans-serif;
		}
		

		* {box-sizing:border-box}

		  /* Make the image fully responsive */
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Hide the images by default */
.mySlides {

  display: none;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: aqua;
  background-color: orangered;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
/*.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}*/

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */



		.main_div{
				width: 100%;
				height: 100vh;
				position: relative;
			}
			.box{
				width: 500px;
				position: absolute;
				top: 15%;
				left: 20%;
				transform: translate(-30%,-15%);
				padding: 70px;
				
				border-radius: 60px;
		
			 background: black;}

			.box h1{
					margin-bottom: 40px;
					margin-left: 125px;
					margin-right: 250px;
	               
					color: white;
					text-align: center;
					text-transform: capitalize;
				}
				.box .inputbox {position: relative;background-color: black;color:white;}

				.box .inputbox input{
					width: 100%;
					padding: 10px;
					font-size: 16px;
					color: white;
					letter-spacing: 1px;
					margin-bottom: 5px;

					border:none;
					
					border-bottom: 1px solid orange;
					background:transparent;
					 background: black;
					 outline:none;
               


				}
			
		        .box .inputbox input[type="submit"]{background-color: black;}
                .box  input[type="submit"]{
                	background:transparent;
                	border:none;
                	outline:none;
                	color: #fff;
                	background:orange;
                	padding: 8px 175px;
                	border-radius: 12px;
                	font-size: 14px;
                 margin-right: 8px;
                      margin-left: -10px;

                      
                }
                .box2{
				width: 500px;
				position: absolute;
				top: 53%;
				right: 20%;
				transform: translate(30%,-57%);
				padding: 20px;
				
				border-radius: 40px;
		
			 background: black;}

			.box2 h1{
					margin-bottom: 45px;
					margin-left: 140px;
					margin-right: 338px;
	
					color: white;
					text-align: center;
					text-transform: capitalize;
				}
				.box2 .inputbox2 {position: relative;background-color: black;color: white;}

				.box2 .inputbox2 input{
					width: 100%;
					padding: 10px;
					font-size: 16px;
					color: white;
					letter-spacing: 1px;
					margin-bottom: 10px;
					margin-right:15px; 
					margin-left:10px;

					border:none;
					
					border-bottom: 1px solid orange;
					background:transparent;
					 background: black;
				


				}
			
		        .box2 .inputbox2 input[type="submit"]{background-color: black;}
                .box2  input[type="submit"]{
                	background:transparent;
                	border:none;
                	outline:none;
                	color: #fff;
                	background:orange;
                	padding: 8px 215px;
                	border-radius: 10px;
                	font-size: 14px;
                 margin-right: 7px;
                      margin-left: -5px;

                      
                }









                #message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}



                #message2 {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message2 p {
  padding: 10px 35px;
  font-size: 18px;
}
/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}








	</style>
	</head>
	<body>

    



<div style="background-color: deeppink;background-image: radial-gradient(circle at 50% top, rgba(128, 0, 0,1) 0%, rgba(255, 0, 0,1) 75%),radial-gradient(circle at right top, #cc1eb4 0%, rgba(128, 0, 0,0) 57%);padding-bottom: 20px; opacity: 1.5;border: 18px solid orange;" class="container-fluid" id="section1">
	
	<h1 style="text-align: center;font-size: 50px;color:yellow;font-family: Lobster Two;text-shadow: 2px 2px black;padding-top: 50px;background-color: deeppink;background-image: radial-gradient(circle at 50% top, rgba(128, 0, 0,0.6) 0%, rgba(255, 0, 0,1) 75%),radial-gradient(circle at right top, #cc1eb4 0%, rgba(128, 0, 0,0) 57%);padding-bottom: 20px;">ONLINE RANDI KHANA</h1>
	<p style="color: yellow;text-align: center;font-size: 35px;font-family: Lobster Two;text-shadow: 1px 1px black;padding-bottom: 50px;background-color: deeppink;background-image: radial-gradient(circle at 50% top, rgba(128, 0, 0,0.6) 0%, rgba(255, 0, 0,1) 75%),radial-gradient(circle at right top, #cc1eb4 0%, rgba(128, 0, 0,0) 57%);padding-bottom: 20px;">BOOK TODAY GET TOMORROW</p>

</div>

<div class="container-fluid" id="section2">
<div class="main_div">

		<div class="box">
			<h1>LOGIN</h1>
			<form id="1" method="POST" action=''>

			<div class="inputbox">
			      

                   Name
				<input type="text" name="username" value="" ><br>
							</div>
			<div class="inputbox">
			
                      Password
				<input type="password" name="pass" value="" >
							</div>
			<input type="submit" name="submit" value="login">
		    </form>
		</div>
		<div class="box2">
			<h1>signup</h1>
			<form  id="2" method="POST" action=" ">
			<div class="inputbox2">
			      

                   Name
				<input type="text" id="myText" name="a" value="" ><br>
							</div>
			<div class="inputbox2">
			
                      Userid
				<input type="text" id="myText" name="b" value=''>
							</div>
		                    
		                    <div class="inputbox2">Email
		               <input type="email" id="myEmail" name="c" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
							</div>
                             <div class="inputbox2">Phone Number
                   		<input type="number" id="myNumber" name="d" value="">
                   			</div>


                   			<div class="inputbox2"> Password
			<input type="password" id="e" name="e" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                            </div>

			<input type="submit" name="enter" value="Signup">
		    </form>
		</div>
    <?PHP
$user="root";
$pass="";
$db="randikhana";
$link=mysql_connect('localhost',$user,$pass);
if(!$link)
die("unable to open database");
mysql_select_db($db) OR die("unable to open file");




$login=$_POST['username'];
$logpass=$_POST['pass'];
$q="SELECT * FROM  customersignup WHERE name='$login' and confirmpassword='$logpass'";//user and pas are the same name given in the field of database table whereas login and pass are the name given in the html files
$result=mysql_query($q);
if($result)
{
if(mysql_num_rows($result)==1)
{
header("location:asholfinalthankyou.php");
exit();

}
else
{
header("location:animatedloginsignup.html");
exit();
}
}
else
{
die("query failed");
}

?>

<?PHP
$user="root";
$pass="";
$db="randikhana";
$link=mysql_connect('localhost',$user,$pass);
if(!$link)
die("unable to open database");
mysql_select_db($db) OR die("unable to open file");




$name=$_POST['a'];
$userid=$_POST['b'];
$email=$_POST['c'];
$password=$_POST['d'];
$confirmpassword=$_POST['e'];
$p="SELECT * FROM customersignup WHERE email='$email' ";
$result=mysql_query($p);

if($result)
{

if(mysql_num_rows($result)==0)


{
$p=mysql_query("insert into customersignup(name,userid,email,password,confirmpassword) values('$name','$userid','$email','$password','$confirmpassword')") or die("insert error");

}
else 
{
echo"<script>
window.open('animatedloginsignup.html');
</script>";
echo "Already registered email";
}
}
else

echo "query failed";
?>




 <div id="message">
  <h3>Password must contain the following:</h3>
  <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
  <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
  <p id="number" class="invalid">A <b>number</b></p>
  <p id="length" class="invalid">Minimum <b>8 characters</b></p>
</div>
				
<script>
var myInput = document.getElementById("d");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>





    </div>
</div>
<div class="container-fluid" id="section3" style="background-color:blanchedalmond;">

<div class="slideshow-container">

  <div class="mySlides ">
   
    <img src="sd1.jpg" style="width:100%">
    <div class="text">Caption Text</div>
  </div>

  <div class="mySlides ">
    <img src="db1.jpg" style="width:100%">
    <div class="text">Caption Two</div>
  </div>

  <div class="mySlides ">
    <img src="arc4.jpg" style="width:100%">
    <div class="text">Caption Three</div>
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<!-- The dots/circles -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
</div>

<script type="text/javascript">
var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
</script>
</div>
</div>
</div>
<div class="container-fluid" id="section4">
<div style="text-align:center">
		<button onclick="Pause()">play/pause</button>
		<button onclick="Big()">big</button>
		<button onclick="Small()">small</button>
		<button onclick="Normal()">normal</button><br><br>
		<video id="v1" width="520" controls><source src="d.mp4" type="video/mp4">
			</video>
			</div>
		<script type="text/javascript">
			var m=document.getElementById("v1");
			function Pause(){
				if(m.paused)
					m.play();
				else
					m.pause();
			}
			function Big()
			{m.width=800;}
    function Small()
			{m.width=520;}
			function Normal()
			{m.width=620;}

		</script>
	</div>



</div>







<div  id="section5">
	<footer style="text-align: center;background-color: gainsboro;color: black;padding: 80px;border-top-left-radius: 25px;border-top-right-radius: 25px">
         © Copyright 2019, ANUDIPTTA DE
</footer>
	
</div>


</body>
</html>