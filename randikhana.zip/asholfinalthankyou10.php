<?php session_start(); ?>

<html>
<head>
  <title>Online Randikhana</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Teko:wght@300&display=swap" rel="stylesheet">
	<title></title>

	<style>
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			
			font-family: 'Josefin Sans', sans-serif;
		}


/* Left and right column */
/*.column.side {
	 
  width: 28%;
}

/* Middle column */



/* Clear floats after the columns */


/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */





  .main_div{
        width: 100%;
        height: 120vh;
        position: relative;
        background-color: lightgrey; 
      }
      .box{
        width: 1000px;
        height: 90vh;
        position: relative;
         top: -25%;
        left: -25%;
        transform: translate(50%,50%);
        padding: 70px;
        background: white;}

.box.column{
float: left;}

.box.column.left{
width: 50%;
text-align: center;
}



.box.column.side{
width: 40%;
text-align: center;
}
.box.row:after{
  content: "";
  display: table;
  clear: both;
}

.footer.text-light{
  background-color:black;padding-right: 10%;border-top-right-radius: 10px;border-top-left-radius: 10px;margin-left: 0%;width: 100%;margin-top: 5%;padding-bottom: 5%;
}

@media screen and (max-width: 600px) {
  .box.column.left,.box.column.side{
    width: 100%;
  }
}


.button {
  background-color: red;
  border: none;
  color: white;
  padding: 16px 15px;
  text-align: center;
  font-size: 16px;
 opacity: 0.6;
  transition: 0.3s;
  text-decoration: none;
  cursor: pointer;
  width: 20%;
  margin-left: 20%;
   
   border-radius: 0px;
}
.button:hover {opacity: 1; box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);}

      

		</style>
</head>
<body>


<div class="progress">
  <div class="progress-bar bg-danger" role="progressbar" style="width: 100%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
</div>


<div style="background-color: deeppink;background-image: radial-gradient(circle at 50% top, rgba(128, 0, 0,1) 0%, rgba(255, 0, 0,1) 75%),radial-gradient(circle at right top, #cc1eb4 0%, rgba(128, 0, 0,0) 57%);padding-bottom: 20px; opacity: 1.5;border: 18px solid orange;" class="container-fluid" id="section1">
  
  <h1 style="text-align: center;font-size: 50px;color:yellow;font-family: Lobster Two;text-shadow: 2px 2px black;padding-top: 50px;background-color: deeppink;background-image: radial-gradient(circle at 50% top, rgba(128, 0, 0,0.6) 0%, rgba(255, 0, 0,1) 75%),radial-gradient(circle at right top, #cc1eb4 0%, rgba(128, 0, 0,0) 57%);padding-bottom: 20px;">ONLINE RANDIKHANA</h1>
  <p style="color: yellow;text-align: center;font-size: 35px;font-family: Lobster Two;text-shadow: 1px 1px black;padding-bottom: 50px;background-color: deeppink;background-image: radial-gradient(circle at 50% top, rgba(128, 0, 0,0.6) 0%, rgba(255, 0, 0,1) 75%),radial-gradient(circle at right top, #cc1eb4 0%, rgba(128, 0, 0,0) 57%);padding-bottom: 20px;">BOOK TODAY GET TOMORROW</p>

</div>

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="newcart.php">Home</a></li>
    <li class="breadcrumb-item"><a href="insidecart10.php">Product Details</a></li>
    <li class="breadcrumb-item active" aria-current="page">NOOB</li>
  </ol>
</nav>


<div style="text-align:left;color:black;font-size: 60px;font-family: Lobster Two;margin-left:5%;">Thankyou
</div>


<div class="container-fluid" id="section1">
<div class="main_div">
 <div class="box">
    
 <?php
//if($_POST){
 // $_SESSION['username']=$_POST['username'];
  echo 'Logged in as:'.$_SESSION['username'].' ';
//}
          ?>


<div class="row">
  <div class="column left text-secondary">
   <img src="image/arc1.jpg" width=250 height=200>
   <h4>NOOB</h4>
   <div>
     <p style="font-family: 'Teko', sans-serif;"></p>
  <p>
       <form id="1"method="POST" action=''><input type="hidden" name="productid" value='FM798'>
       <div class="inputbox">
        Give your address here
        <input type="textarea" name="address" value=' ' required><br>
              </div>
        
  <div>          
choose ur time
  <select name=w>
     <option>0
    <option>1
    <option>2
    <option>3
    <option>4
    <option>5
    <option>6
    <option>7
    <option>8
    <option>9
    <option>10
  </select><br>
</div>
  <input type="hidden" name="username" value=" <?php
  echo ''.$_SESSION['username'].' ';
          ?>">
        <div><label for="birthday">Date for service:</label>
  <input type="date" id="birthday" name="birthday" pattern="[0-9]"required><br></div>
   <label for="appt">Select a time:</label>
  <input type="time" id="appt" name="appt"><br>

    <input type="submit" name="boroda" value="Give details and then pay">

    </form>
   </p>
  </div>
    
 
</div>
<div class="column middle">
  <h2 style="margin-left: 20%;">Scan QR code</h2>
  <h2 style="margin-left: 60%;">Or Pay</h2>
<img src="image/code.jpg" height="280" width="290" style="margin-left: 10%;">
<h4 style="margin-left: 25%;">For convinence:</h4>
<h2 style="margin-left: 25%;">Then print bill</h2>
</div>
 <div class="column side"><h2>to Pay Now</h2>
<h2>Directly</h2>
<img src="image/codedetails.jpg" height="280" width="210" style="margin-left: 5%;">
<h4 style="margin-left: 25%;color:blue;">Use Gpay</h4>
  
  </div>  





</div>

<div>
<?php
//if($_POST){
 // $_SESSION['username']=$_POST['username'];
    
              $con = mysqli_connect('localhost','root','');
  mysqli_select_db($con,'randikhana');
            if(!con)
              die(mysql_error());
          if(isset($_POST['boroda']) && $_POST['boroda']!=""){
          $pou=$_POST['productid'];
          $l=$_POST['address'];
          $lon=$_POST['w'];
           $t=$_POST["w"];
          $anu=$_POST["username"];
           $dat=$_POST['birthday'];
            $tim=$_POST['appt'];
            $y=100;
            $u=$t*$y;
            $i=18;
            $z=$i*$u;
            $o=100;
            $e=$z/$o;
            $h=$e+$u;
            if($pou == NULL || $l == NULL || $t == NULL){
            echo "ENTER VALID ADDRESS,taka";

          }
          else
            
           $sql = "INSERT INTO otherdetails(productid,address,taka,nam,datey,timo)
VALUES('$pou','$l','$lon','$anu','$dat','$tim') ";
         mysqli_query($con, $sql) or die("hoibonijani");
          echo "Your product code is $pou,Your address is $l,Your bill  for $t hour with 18% gst will be $h and will be serviced on $dat";
     


      }
     
          mysqli_close($con);?>
</div>
</div>

</div>
<div>
<div class="btn-group btn-group-justified mx-auto" style="width: 100%;">
 <button onclick="window.print()" class="btn btn-warning pb-3 pt-2">Print bill</button>
    <a href="success.php" class="btn btn-danger ml-5  pb-3 pt-2">Continue shopping</a>
    <a href="success.php" class="btn btn-primary ml-5 pb-3 pt-2">Logout</button>
</div>
</div>
</div>
<div class="container-fluid" id="section2">
       <div class="footer text-light">
        <div id="footer_inner "style="text-align: center;">
         
            <ul id="footer_nav" style="text-align: center;">
<li id="footer-nav-regular-member" style="display:inline-block;font-family: 'Roboto Mono', monospace;"><a href="animatedloginsignup.html">Regular member</a><small>|</small></li>
<!--<li id='footer-nav-current-students'><a href="NITAmain/students/currentStudents/currentStudentsHome.html">Current Students</a></li>-->
<li id="footer-nav-new-member"  style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="animatedloginsignup.html">New Member</a><small>|</small></li>
<li id="footer-nav-porn" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://xxxhub.cc/pornhub2-video-ass-homemade-couple/">Pornhub</a><small>|</small></li>
<li id="footer-nav-adminstration"style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.xvideos3.com/video12765801/xvideos-2">Xvideos</a><small>|</small></li>
<li id="footer-nav-placement-cell" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.youtube.com/watch?v=-cpYVpADtmE">Youtube</a><small>|</small></li>
<li id="footer-nav-about" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="about.html">About</a><small>|</small></li>
<li id="footer-nav-news--events" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.dainiksambad.com/">News</a><small>|</small></li>
<li id="footer-nav-contact" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="bookservices.php">Contact</a><small>|</small></li>
<li id="footer-nav-degree-programs" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="#">Programmes</a></li></ul>
          
<div id="contact_copyright">
<!--<p align=right><a target="_blank" href="https://twitter.com/NITAgartalaoffi"><img src=NITAmain/images/twiter.png alt="" width="30px" height="30px"></a> <a target="_blank" href="https://facebook.com/nit.agartala.501"><img src=NITAmain/images/facebook.png alt="" width="30px" height="30px"></a>
</p>-->
<p id="footer_contact"><h3>CONTACT US</h3> <small></small><h6>PHONE: 143-69-26  </h6><small>  </small><h6> EMAIL:ecestudent@gmail.com, ownerrandikhana@gmail.com </h6><small>  </small> <a target="_blank" href="https://instagram.com/anudipto_de"><img src="image/instra.jpg" alt="" width="30px" height="30px"></a> <small>  </small><a target="_blank" href="https://www.facebook.com/anudiptta.de"><img src="image/facebook.png" alt="" width="30px" height="30px"></a>
</p>

<p id="copyright"><h3>COPYRIGHT ©RK Agartala.</h3></p></div></div>

<div class="copywrite-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copywrite-content d-flex flex-wrap justify-content-between align-items-center">
                            <!-- Footer Logo -->
                            <a href="https://anudiptta-de.github.io/portfolio/" class="footer-logo"><img src="image/logo3.jpg" width="120" height="70" alt=""></a>

                            <!-- Copywrite Text -->
                            <p class="copywrite-text"><a href="https://anudiptta-de.github.io/portfolio/"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is designed by <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://anudiptta-de.github.io/portfolio/" target="_blank">MR 17UEC095</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </div></div></div>

</div>
</body>
</html>