<!DOCTYPE html>
<html>
<head>
<title>Online Randikhana</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/touchTouch.css" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Monoton' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
<!---//End-css-style-switecher----->

<style>
* {box-sizing: border-box}
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 12px;
  color: white;
  text-decoration: none;
  font-size: 17px;
  width: 25%; /* Four links of equal widths */
  text-align: center;
}

.navbar a:hover {
  background-color: #000;
}

.navbar a.active {
  background-color: #4CAF50;
}

@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body style="background-image: url(main.jpg); background-image:cover;">
<div class="header">
     <div class="container">
         
        <div class="navbar">
  <a  href="newcart.php"><i class="fa fa-fw fa-home"></i> Home</a> 
  <a href="http://www.google.com"><i class="fa fa-fw fa-search"></i> Search</a> 
  <a  class="active" href="#"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  <a href="about.html"><i class="fa fa-fw fa-user"></i> About</a>
</div>
         </div>
         <div class="clearfix"></div>
     </div>
</div>
        <div class="contact">
            <div class="container"> 		 

		
			 <div class="contact-grids">
				 <div class="col-md-6 contact-left">
					 <p text-light>Write your query now. </p>
					 <form method="post" action=''>
					 	
						 
							 <ul class="text-warning">Name: 
							 <input type="text" class="form-control" name="contactname" required="true">
						 </ul>					 				 
						 
							 <ul class="text-warning">Email: 
							<input type="email" class="form-control" name="contactemail" required="true">
						 </ul>
						 
						 
							 <ul class="text-warning">Mobile Number: 
							<input type="text" class="text" name="contactmobnum" required="true" maxlength="10" pattern="[0-9]+">
						 </ul>
												 
						
						 
							 <ul class="text-warning">Comments:
							<textarea type="text" class="form-control" name="contactcomment" required="true"></textarea>
						 </ul>					
						 <input type="submit" name="submit" value="Submit">					 
					 </form>
				 </div>
			
				 <div class="clearfix"></div>
			 </div>
		 </div>
		 <div class="footer">
     <div class="container">
         <div class="strp">
             <img src="ftr.png" alt=""/>
         </div>
         <div class="copywrite">
             <p>Copyright © 2020 Online Randikhana </p>
         </div>
         <div class="social-icons">
              <a href="www.twitter.com"><i class="twitter"></i></a>
              <a href="www.facebook.com"><i class="facebook"></i></a>      
         </div>
         <div class="clearfix"></div>
     </div>
     </div> 
	 </div>
</div>

<?PHP
$user="root";
$pass="";
$db="randikhana";
$link=mysql_connect('localhost',$user,$pass);
if(!$link)
die("unable to open database");
mysql_select_db($db) OR die("unable to open file");


if(isset($_POST['submit']) && $_POST['submit']!=""){

$cname=$_POST['contactname'];
$cuserid=$_POST['contanctemail'];
$cemail=$_POST['contactmobnum'];
$cpassword=$_POST['contactcomment'];

$p=("insert into tblbooking(Name,Email,Number,comment) values('$cname','$cuserid','$cemail','$cpassword')") or die("insert error");
 mysql_query( $p,$link) or die("hoibonijani");
 echo "Thankyou $cname our team will contact you as soon as possible;";
}
?>
</body>
</html>