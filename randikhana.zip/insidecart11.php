<?php  session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Online Randikhana</title>
	 <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script" rel="stylesheet">
 
<link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Acme&family=Nanum+Myeongjo&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&display=swap" rel="stylesheet">

	<style>


.progress-container {
  width: 100%;
  height: 10px;
  background-color: red ;
}

.progress-bar {
  height: 10px;
  background-color: blue;
  width: 0%;
}


.sidenav {
  height: 100%;
  width: 10%;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:red;
  overflow-x: hidden;
  padding-top: 20px;
  margin-top: 228px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.column {
  float: left;
  padding: 10px;
  margin-left: 10px;
}

/* Left and right column */
.column.side {
  width: 28%;
}

/* Middle column */
.column.middle {
  width: 28%;
}

.column.right {
  width: 40%;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column.side, .column.middle {
    width: 100%;
  }
}

.grid-container {
  display: grid;
  grid-template-columns: 180;
  grid-gap: 0px;
  background-color: white;
   box-shadow: 2px 2px black;
}

.grid-container  div {
  background-color:lightgrey;
  text-align: center;
  padding: 10px 0;

}


.hover-image img:hover {
  -ms-transform: scale(1.5); /* IE 9 */
  -webkit-transform: scale(1.5); /* Safari 3-8 */
  transform: scale(1.8); 
  opacity: 1.5;
}

.checked {
  color: orange;}

#myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

#myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}



/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 70px;
  right: 70px;
  color: cyan;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}
  
.card{padding-right:0px;padding-left:0px;
  border: 1px solid;
  padding: 10px;
  box-shadow: 5px 10px 18px red;
}

.button {
  background-color: red;
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  font-size: 16px;
  margin: 4px 2px;
  opacity: 0.6;
  transition: 0.3s;
  display: inline-block;
  text-decoration: none;
  cursor: pointer;
  width: 70%;
  margin-left: 20%;
   margin-top:  20%;
   border-radius: 0px;
}

.button:hover {opacity: 1; box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);}
</style>



</head>
<body>
	

<nav class="navbar navbar-expand-lg navbar-dark  fixed-top" style="margin:0px 0;padding-bottom: 5px;padding-top: 5px;">
  <a class="navbar-brand" style="padding: 5px; padding-left: 15px;" href="https://anudiptta-de.github.io/portfolio/"><img src="image/logo3.jpg" width="120" height="70" alt=""></a>
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navb" aria-expanded="true">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="navbar-collapse collapse show" id="navb" style="">
    <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link " style="padding: 5px;" href="newcart.php" id="navbardrop"  >
      
        Home
    
      </a>

    </li>
            <li class="nav-item "  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link " style="padding: 5px;" href="about.html" id="navbar"  >
      	
        About Us
    
      </a>
    </li>
         <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link dropdown-toggle" style="padding: 5px;" href="#" id="navbardrop" data-toggle="dropdown" >
      	
        Porn Link
    
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="https://xxxhub.cc/pornhub2-video-ass-homemade-couple/">Pornhub</a>
        <a class="dropdown-item" href="https://www.xvideos3.com/video12765801/xvideos-2">Xvideos</a>
        <a class="dropdown-item" href="https://xhamster3.desi/channels/brazzers
">Brazzers</a>
        <a class="dropdown-item" href="https://www.youtube.com/watch?v=-cpYVpADtmE">Youtube</a>
      </div>
    </li>
          <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link dropdown-toggle" style="padding: 5px;" href="#" id="navbardrop" data-toggle="dropdown" >
      	
        Services

      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="https://www.oyorooms.com/">
Hotels and resorts Booking</a>
        <a class="dropdown-item" href=">
https://www.durexindia.com/collections/condoms">
Condoms</a>
        <a class="dropdown-item" href="
https://vymaps.com/IN/Pradip-saha-wine-shop-147158/">Whiskey Delivery</a>
      </div>
    </li>

         <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link " style="padding: 5px;" href="bookservices.php" id="navbardrop" >
        
        Contact Us
    
      </a>
    </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" id="tfnewsearch" method="get"  action="http://www.google.com">
      <input class="form-control mr-sm-2" type="text" placeholder="Search">
      <button class="btn btn-success my-2 my-sm-0" name="y" type="submit" >Search</button>
    </form>
  </div>
</nav>



<div class="container-fluid " id="section1" style="background-color: #3B2F63;background-image: radial-gradient(circle at 50% top, rgba(84,90,182,0.6) 0%, rgba(84,90,182,0) 75%),radial-gradient(circle at right top, #794aa2 0%, rgba(121,74,162,0) 57%);padding-bottom: 20px;">
	<h1 class="text-center text-warning mb-5" 
	style="font-family: 'Abril Fatface', cursive;padding-top: 100px;">ONLINE RANDIKHANA</h1>
</div>








<div class="container-fluid" id="section2">





<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="newcart.php">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">MUNNI</li>
  </ol>
</nav>


<div class="row">
  <div class="column side">
   
    
         
 <div> <img id="myImg" src="image/sk4.jpg" alt="Click me" style="width:100%;max-width:400px;">

<!-- The Modal -->
<div id="Modal" class="modal">
  <span class="close">&times;</span>
  <img class="modal-content" id="img01">
  <div id="caption"></div>
</div>

<script>
// Get the modal
var modal = document.getElementById("Modal");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
  modal.style.display = "none";
}
</script>

    </div>
    <div class="hover-image">
    <img  src="image/sk2.jpg" alt="MUNNI" style="width:360px;border-radius: 5px">
</div>
 <div class="hover-image">
    <img  src="image/sk3.jpg" alt="MUNNI" style="width:360px;border-radius: 5px">
</div>
</div>
  
  <div class="column middle">
     <div class="grid-container">
  <div style="text-align: center;"> <h1 style="font-family: 'Acme', sans-serif;
          border-bottom: 1px solid black;">PERSONAL DETAILS</h1><br>
    <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;" >Height : 5'11"</h2><br>
    <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Weight : 60 kg</h2><br>
            <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Age : 22 </h2><br>
            <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Eyes:Black</h2><br>
            <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Dress Size: M</h2><br>
            <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Languages:English,bangla</h2><br>
            <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Availability:At night</h2><br>
            <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Nationality: Indian</h2><br>
            <h2 style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;
          border-bottom: 1px solid black;">Incall/Outcall : Both</h2>
    </div>
  <div> 
    </div>  
  </div>
  
  </div>
  <div class="column right">

    <h2 class="text-align-left text-danger mb-0">PRICE :₹250/hr (DISCOUNT:20%)</h2>

       <h3 class="text-align-left text-information mb-4">In Profession for 20 yrs </h3>
       <h3 class="text-align-left mb-0">Star Rating</h3><span class="fa fa-star checked mb-1"></span>
       <span class="fa fa-star checked mb-1"></span>
       <span class="fa fa-star checked mb-1"></span>
       <span class="fa fa-star mb-1"></span>
       <span class="fa fa-star mb-1"></span>
  

<div >
            <h1 class="text-information" style="text-align: left;font-family: 'Acme', sans-serif;margin-bottom: 10%;
        ">Free Delivery</h1>
            </div>

<div>
  <button class="btn btn-success my-5 my-sm-0 " onclick="myFunction()"> CLICK FOR EXACT AMOUNT WITH GST</button>

<p id="demo"></p>

<script>
function myFunction() {
  var txt;
  var a=250;
  var b;
  var c=0;
  var person = (prompt("Please enter how many hours:", " "));
  var b=a*person;
  var gst=18;
  var gsta=gst/100;
  var gstb=gsta*b;
  var gstc=gstb+b;
  if (person == null || person == " " || person == 'isNaN()' ) {
    txt = "User cancelled the prompt.";
  } else
  if(person<=c) {
    txt = "Enter more than 0 and less than 10 value";
  }
  else
    if(person>10) {
        txt = "Enter less than 10 and more than 0 value"; 
    }else
    {  txt = "<h1>Your bill would be   " + gstc + "   rupees along with 18% gst</h1>"; }
  document.getElementById("demo").innerHTML = txt;
}
</script>
</div>





<div >
            <h1 style="text-align: left;font-family: 'Acme', sans-serif;
          border-bottom: 1px solid black;">Services will be done</h1>
            <p style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;">Free services: Blow job, Couple service, Dirty talk, Domination, Erotic massage, Face sitting, Fetish, Foot fuck, Girlfriend/Boyfriend experience, Hand job, Massage, Oral sex, Role play, Shower play, Tongue kisses, Golden Shower</p> 
          </div>



<div >
            <h1 style="text-align: left;font-family: 'Acme', sans-serif;
          border-bottom: 1px solid black;">About Me</h1>
            <p style="font-family: 'Acme', sans-serif;
font-family: 'Nanum Myeongjo', serif;">I want to be fucked ,if you are interested in me call me or book me.We will be doing dangal in night ,ohh it feels so sexy.Come on book me I am waiting for you</p> 
          </div>


<div>
    <form id="2" method="POST" action='animatedloginsignup11.html'>
      <button class="button" type="submit" >Finalize Booking</button>
    </form>

</div>


   

  <div id="section5" style="margin-top: 10%;">
 <center>
<h1 style="font-size:50pt;color:green" id="ab"></h1>
</center>
<script>
var n=setInterval(abc,1000);
function abc()
{
var d=new Date();
 document.getElementById("ab").innerHTML=d.toLocaleTimeString();
}
</script>
 <center>
<h5 style="font-size:20pt;color:darkgreen" id="abp"></h5>
</center>
<script>
var n=setInterval(abc,1000);
function abc()
{
var d=new Date();
 document.getElementById("abp").innerHTML=d.toLocaleDateString();
}
</script>

</div>
</div>
</div>

 	
<div class="container-fluid" id="section4">
       <div id="footer" style="background-color: lightgrey;padding-right: 10%;border-top-right-radius: 10px;border-top-left-radius: 10px;margin-left: 0%;width: 100%;margin-top: 5%;padding-bottom: 5%;">
        <div id="footer_inner">
         
            <ul id="footer_nav" style="text-align: center;">
<li id="footer-nav-regular-member" style="display:inline-block;font-family: 'Roboto Mono', monospace;"><a href="animatedloginsignup.html">Regular member</a><small>|</small></li>
<!--<li id='footer-nav-current-students'><a href="NITAmain/students/currentStudents/currentStudentsHome.html">Current Students</a></li>-->
<li id="footer-nav-new-member"  style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="animatedloginsignup.html">New Member</a><small>|</small></li>
<li id="footer-nav-porn" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://xxxhub.cc/pornhub2-video-ass-homemade-couple/">Pornhub</a><small>|</small></li>
<li id="footer-nav-adminstration"style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.xvideos3.com/video12765801/xvideos-2">Xvideos2</a><small>|</small></li>
<li id="footer-nav-placement-cell" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.youtube.com/watch?v=-cpYVpADtmE">Youtube</a><small>|</small></li>
<li id="footer-nav-about" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="about.html">About</a><small>|</small></li>
<li id="footer-nav-news--events" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.dainiksambadnews.com/">News</a><small>|</small></li>
<li id="footer-nav-contact" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="bookservices.php">Contact</a><small>|</small></li>
<li id="footer-nav-degree-programs" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="#">Programmes</a></li></ul>
          
<div id="contact_copyright" style="font-family: 'Josefin Sans', sans-serif; text-align: center;">
<!--<p align=right><a target="_blank" href="https://twitter.com/NITAgartalaoffi"><img src=NITAmain/images/twiter.png alt="" width="30px" height="30px"></a> <a target="_blank" href="https://facebook.com/nit.agartala.501"><img src=NITAmain/images/facebook.png alt="" width="30px" height="30px"></a>
</p>-->
<p id="footer_contact"><h3>CONTACT US</h3> <small></small><h6>PHONE: 143-69-26  </h6><small>  </small><h6> EMAIL:ecestudent@gmail.com, ownerrandikhana@gmail.com </h6><small>  </small> <a target="_blank" href="https://instagram.com/anudipto_de"><img src="image/instra.jpg" alt="" width="30px" height="30px"></a> <small>  </small><a target="_blank" href="https://www.facebook.com/anudiptta.de"><img src="image/facebook.png" alt="" width="30px" height="30px"></a>
</p>

<p id="copyright"><h3>COPYRIGHT ©RK Agartala.</h3> </p></div>
</div>
<div class="copywrite-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copywrite-content d-flex flex-wrap justify-content-between align-items-center">
                            <!-- Footer Logo -->
                            <a href="https://anudiptta-de.github.io/portfolio/" class="footer-logo"><img src="image/logo3.jpg" width="120" height="70" alt=""></a>

                            <!-- Copywrite Text -->
                            <p class="copywrite-text"><a href="https://anudiptta-de.github.io/portfolio/"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is designed by <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://anudiptta-de.github.io/portfolio/" target="_blank">MR 17UEC095</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div></div></div></div></div></div></div></div>
</body>
</html>