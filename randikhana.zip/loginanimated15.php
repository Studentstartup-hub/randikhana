<?php session_start(); ?>
<?PHP
$user="root";
$pass="";
$db="randikhana";
$link=mysql_connect('localhost',$user,$pass);
if(!$link)
die("unable to open database");
mysql_select_db($db) OR die("unable to open file");


if($_POST){
  $_SESSION['username']=$_POST['username'];
}
         


$login=$_POST['username'];
$logpass=$_POST['pass'];
$q="SELECT * FROM  customersignup WHERE name='$login' and confirmpassword='$logpass'";//user and pas are the same name given in the field of database table whereas login and pass are the name given in the html files
$result=mysql_query($q);
if($result)
{
if(mysql_num_rows($result)==1)
{
header("location:asholfinalthankyou15.php");
exit();

}
else
{
echo"<script>
window.open('animatedloginsignup15.html');
</script>";
echo "Incorrect name/password or Not signup";
}
}
else
{
die("query failed");
}

?>


