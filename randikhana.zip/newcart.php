
<html>
<head>
	<title>Online Randikhana</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
 <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:ital@1&display=swap" rel="stylesheet">
	  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Acme&family=Nanum+Myeongjo&display=swap" rel="stylesheet">

<style>

*{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      
      font-family: 'Josefin Sans', sans-serif;
    }



.sidenav {
  height: 100%;
  width: 15%;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:grey;
  overflow-x: hidden;
  padding-top: 10px;
  margin-top: 242px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: black;
  display: block;

}

.sidenav a:hover {
  color: red;
}

/*.container-fluid{
  box-sizing: border-box;
}*/
.card{padding-right:10px;padding-left:0px;
  padding: 10px;
  box-shadow: 5px 5px 10px darkgrey;
}


/* Container for flexboxes */
/*.row {
  display: flex;
  flex-wrap: wrap;
}

 Create four equal columns 
.card {
  flex: 25%;
  padding: 20px;
}

 On screens that are 992px wide or less, go from four columns to two columns 
@media screen and (max-width: 992px) {
  .card {
    flex: 25%;
  }
}

 On screens that are 600px wide or less, make the columns stack on top of each other instead of next to each other 
@media screen and (max-width: 600px) {
  .row {
    flex-direction: card;
  }
}*/

.open-button {
  background-color: #3B2F63;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 1.5;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
  border-radius: 15px;
}

/* The popup chat - hidden by default */
.chat-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width textarea */
.form-container textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: aqua;
  resize: none;
  min-height: 200px;
}

/* When the textarea gets focus, do something */
.form-container textarea:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/send button */
.form-container .btn {
  background-color: yellowgreen;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
  border-radius: 10px;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: firebrick;
  border-radius: 10px;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}

.dropbtn {
  background-color: teal;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  right: 0;
  min-width: 120px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: royalblue;}
.dropdown:hover .dropdown-content {display: block;}
.dropdown:hover .dropbtn {background-color: orange;}
</style>






</head>
<body >

	


  
<nav class="navbar navbar-expand-lg navbar-light  fixed-top" style="margin:0px 0;padding-bottom: 10px;">
  <a class="navbar-brand" style="padding: 10px; padding-left: 15px;" href="https://anudiptta-de.github.io/portfolio/"><img src="image/logo3.jpg" width="120" height="70" alt=""></a>
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navb" aria-expanded="true">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="navbar-collapse collapse show" id="navb" style="">
    <ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link " style="padding: 5px;" href="newcart.php" id="navbardrop"  >
      
        Home
    
      </a>
     
    </li>
            <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link " style="padding: 5px;" href="about.html" id="navbardrop" >
      	
        About Us
    
      </a>
     
    </li>
         <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link dropdown-toggle " style="padding: 5px;" href="#" id="navbardrop" data-toggle="dropdown" >
      	
        Porn link
    
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="https://xxxhub.cc/pornhub2-video-ass-homemade-couple/">Pornhub</a>
        <a class="dropdown-item" href="https://www.xvideos3.com/video12765801/xvideos-2">Xvideos</a>
        <a class="dropdown-item" href="https://xhamster3.desi/channels/brazzers">Brizzards</a>
         <a class="dropdown-item" href="https://www.youtube.com/watch?v=-cpYVpADtmE">Youtube</a>
      </div>
    </li>
          <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link dropdown-toggle" style="padding: 5px;" href="#" id="navbardrop" data-toggle="dropdown" >
      	
        Services

      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="https://www.oyorooms.com/">
Hotels and resorts Booking</a>
        <a class="dropdown-item" href="https://www.durexindia.com/collections/condoms">
Condoms</a>
        <a class="dropdown-item" href="https://vymaps.com/IN/Pradip-saha-wine-shop-147158/">Whiskey Delivery</a>
      </div>
    </li>

           <li class="nav-item dropdown"  style="padding: 10px;padding-left: 10px;padding-right: 10px;">
      <a class="nav-link " style="padding: 5px;" href="bookservices.php" id="navbardrop"  >
        
        Contact Us
    
      </a>
     
    </li>
    </ul>
   <form class="form-inline my-2 my-lg-0" id="tfnewsearch" method="get"  action="http://www.google.com">
      <input class="form-control mr-sm-2" type="text" placeholder="Search">
      <button class="btn btn-success my-2 my-sm-0" name="y" type="submit" >Search</button>
    </form>
  </div>
</nav>








<div class="container-fluid" id="section1" style="background-color: #3B2F63;background-image: radial-gradient(circle at 50% top, rgba(84,90,182,0.6) 0%, rgba(84,90,182,0) 75%),radial-gradient(circle at right top, #794aa2 0%, rgba(121,74,162,0) 57%);">
	<h1 class="text-center text-warning mb-0" 
	style="font-family: 'Abril Fatface', cursive;padding-top: 100px;padding-bottom: 10px">ONLINE RANDIKHANA</h1>
<h2 class="text-center text-warning mb-0" 
  style="font-family: 'Abril Fatface', cursive;padding-top: 15px;padding-bottom: 7px">Dard Mein Maja &#8596; Maja Mein Dard</h2>

<p class="text-warning" style="font-family: 'Abril Fatface',cursive;"><marquee>Due to lockdown there may be some time issue</marquee></p>
</div>


<!--div class="TaxBanner-taxBanner text-warning pr-5 " style="text-align: center;width: 100%;background-color: #3B2F63;background-image: radial-gradient(circle at 50% top, rgba(84,90,182,0.6) 0%, rgba(84,90,182,0) 75%),radial-gradient(circle at right top, #794aa2 0%, rgba(121,74,162,0) 57%);"> <h1>Please select your preference from sort item </h1> </div>
<div class="container-fluid" id="section2"-->


<div class="sidenav" id="section2" >
  <div style="text-align: center;">
    <h2><center>Sponsorships</center></h2>
<div class="filterbox">
 <p> 
 <img src="image/kohinoor1.jpg" width=150 height=170>
 <img src="image/condom2.jpg" width=150 height=320></p>


</div>
</div>
</div>

 

<div class="container-fluid">

	   <div class="row" style="margin-left: 15%;margin-bottom: 2%;">

  

<div class="col-sm-3">
   <div class="card bg-light" id="1"><a target="_blank" href="insidecart1.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/db1.jpg" width="235" height="300"><h2 class="text-danger text-center">CHAMIA</h2><h3 class="text-danger text-center">₹500<span>(96% OFF)</span></h3></a><a href="animatedloginsignup1.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

<div class="col-sm-3">
<div class="card bg-light" id="2"><a target="_blank" href="insidecart2.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/sd2.jpg" width="235" height="300"><h2 class="text-danger text-center">CHAMELI</h2><h3 class="text-danger text-center">₹963<span>(7% OFF)</span></h3></a><a href="animatedloginsignup2.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

<div class="col-sm-3">
<div class="card bg-light" id="3">
<a target="_blank" href="insidecart3.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/chandra1.jpg" width="235" height="300"><h2 class="text-danger text-center">HALLALUIA</h2><h3 class="text-danger text-center">₹865<span>(0% OFF)</span></h3></a><a href="animatedloginsignup3.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

<div class="col-sm-3">
<div class="card bg-light" id="4">
<a target="_blank" href="insidecart4.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/sk1.jpg" width="235" height="300"><h2 class="text-danger text-center">PRINCESS</h2><h3 class="text-danger text-center">₹80<span>(8% OFF)</span></h3></a><a href="animatedloginsignup4.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div></div>


 <div class="row" style="margin-left: 15%; margin-bottom: 2%;">
<div class="col-sm-3"><div class="card bg-light" id="5">
<a target="_blank" href="insidecart5.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/sd5.jpg" width="235" height="300"><h2 class="text-danger text-center">GULABO</h2><h3 class="text-danger text-center">₹200<span>(10% OFF)</span></h3></a><a href="animatedloginsignup5.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

<div class="col-sm-3"><div class="card bg-light" id="6">
<a target="_blank" href="insidecart6.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/db2.jpg" width="235" height="300"><h2 class="text-danger text-center">DULARI</h2><h3 class="text-danger text-center">₹868<span>(5% OFF)</span></h3></a><a href="animatedloginsignup6.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

<div class="col-sm-3"><div class="card bg-light" id="7">
<a target="_blank" href="insidecart7.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/sd1.jpg" width="235" height="300"><h2 class="text-danger text-center">RAJJO</h2><h3 class="text-danger text-center">₹1000<span>(6% OFF)</span></h3></a><a href="animatedloginsignup7.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

<div class="col-sm-3"><div class="card bg-light" id="8">
<a target="_blank" href="insidecart8.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/chandra2.jpg" width="235" height="300"><h2 class="text-danger text-center">MIA</h2><h3 class="text-danger text-center">₹165<span>(2% OFF)</span></h3></a><a href="animatedloginsignup8.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div></div>


 <div class="row" style="margin-left: 15%; margin-bottom: 2%;">
  <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart9.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/sk3.jpg" width="235" height="300"><h2 class="text-danger text-center">SHEILA</h2><h3 class="text-danger text-center">₹500<span>(10% OFF)</span></h3></a><a href="animatedloginsignup9.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

  <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart10.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/arc1.jpg" width="235" height="300"><h2 class="text-danger text-center">NOOB</h2><h3 class="text-danger text-center">₹70<span>(90% OFF)</span></h3></a><a href="animatedloginsignup10.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

  <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart11.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/sk4.jpg" width="235" height="300"><h2 class="text-danger text-center">MUNNI</h2><h3 class="text-danger text-center">₹250<span>(20% OFF)</span></h3></a><a href="animatedloginsignup11.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

  <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart12.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/db4.jpg" width="235" height="300"><h2 class="text-danger text-center">RASMALAI</h2><h3 class="text-danger text-center">₹50<span>(10% OFF)</span></h3></a><a href="animatedloginsignup12.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>
</div>

<div class="row" style="margin-left: 15%; margin-bottom: 2%;">
    <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart13.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/db3.jpg" width="235" height="300"><h2 class="text-danger text-center">CHAMELI</h2><h3 class="text-danger text-center">₹325<span>(80% OFF)</span></h3></a><a href="animatedloginsignup13.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

  <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart14.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/arc3.jpg" width="235" height="300"><h2 class="text-danger text-center">ANARKALI</h2><h3 class="text-danger text-center">₹465<span>(65% OFF)</span></h3></a><a href="animatedloginsignup14.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

  <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart15.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/chandra3.jpg" width="235" height="300"><h2 class="text-danger text-center">KOMOL</h2><h3 class="text-danger text-center">₹5<span>(55% OFF)</span></h3></a><a href="animatedloginsignup15.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>

  <div class="col-sm-3">
<div class="card bg-light" id="9">
<a target="_blank" href="insidecart16.php" style="display: inline-block;font-family: 'Acme', sans-serif;"><img src="image/sk2.jpg" width="235" height="300"><h2 class="text-danger text-center">MONA</h2><h3 class="text-danger text-center">₹659<span>(86% OFF)</span></h3></a><a href="animatedloginsignup16.html" button class="btn btn-warning flex-fill text-white"  >Book Now</a></div></div>
</div>
</div>




<button class="open-button" onclick="openForm()">Any Problem?</button>

<div class="chat-popup" id="myForm">
  <form action='' method="POST" class="form-container">
    <h1>Write the problem</h1>
     
       
    <label for="msg"><b>In the box</b></label>
    <textarea placeholder="Enter your name,productid and the problem" name="msg" required></textarea>

    <button type="submit" class="btn">Send</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
<?php
$con=mysql_connect('localhost','root','');
if(!con)
die(mysql_error());
$chat=$_POST['msg'];
mysql_select_db("randikhana");
$we="Insert into chatandfeedback(chat) values('$chat')";
mysql_query($we,$con) or die("link hoisena");
mysql_close($con);
?>












<div class="container-fluid" id="section4">
       <div id="footer" style="background-color: lightgrey;padding-right: 10%;border-top-right-radius: 10px;border-top-left-radius: 10px;margin-left: 15%;width: 86%;margin-top: 5%;padding-bottom: 5%;">
        <div id="footer_inner">
         
            <ul id="footer_nav" style="text-align: center;" >
<li id="footer-nav-regular-member" style="display:inline-block;font-family: 'Roboto Mono', monospace;"><a href="animatedloginsignup.html">Regular member</a><small>|</small></li>
<!--<li id='footer-nav-current-students'><a href="NITAmain/students/currentStudents/currentStudentsHome.html">Current Students</a></li>-->
<li id="footer-nav-new-member"  style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="animatedloginsignup.html">New Member</a><small>|</small></li>
<li id="footer-nav-porn" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://xxxhub.cc/pornhub2-video-ass-homemade-couple/">Pornhub</a><small>|</small></li>
<li id="footer-nav-adminstration"style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.xvideos3.com/video12765801/xvideos-2">Xvideos</a><small>|</small></li>
<li id="footer-nav-placement-cell" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.youtube.com/watch?v=-cpYVpADtmE">Youtube</a><small>|</small></li>
<li id="footer-nav-about" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="about.html">About</a><small>|</small></li>
<li id="footer-nav-news--events" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="https://www.dainiksambad.com/">News</a><small>|</small></li>
<li id="footer-nav-contact" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="bookservices.php">Contact</a><small>|</small></li>
<li id="footer-nav-degree-programs" style="display: inline-block;font-family: 'Roboto Mono', monospace;"><a href="#">Programmes</a></li></ul>
          
<div id="contact_copyright" style="text-align: center;font-family: 'Josefin Sans', sans-serif;">
<!--<p align=right><a target="_blank" href="https://twitter.com/NITAgartalaoffi"><img src=NITAmain/images/twiter.png alt="" width="30px" height="30px"></a> <a target="_blank" href="https://facebook.com/nit.agartala.501"><img src=NITAmain/images/facebook.png alt="" width="30px" height="30px"></a>
</p>-->
<p id="footer_contact"><h3>CONTACT US</h3> <small></small><h6>PHONE: 143-69-26  </h6><small>  </small><h6> EMAIl:ecestudent@gmail.com, ownerrandikhana@gmail.com </h6><small>  </small> <a target="_blank" href="https://instagram.com/anudipto_de"><img src="image/instra.jpg" alt="" width="30px" height="30px"></a> <small>  </small><a target="_blank" href="https://www.facebook.com/anudiptta.de"><img src="image/facebook.png" alt="" width="30px" height="30px"></a>
</p>

<p id="copyright"><h3>COPYRIGHT ©RK Agartala.</h3> <h3>This is a just for fun website,donot take it seriously.</h3></p><div class="copywrite-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copywrite-content d-flex flex-wrap justify-content-between align-items-center">
                            <!-- Footer Logo -->
                            <a href="https://anudiptta-de.github.io/portfolio/" class="footer-logo"><img src="image/logo3.jpg" width="120" height="70" alt=""></a>

                            <!-- Copywrite Text -->
                            <p class="copywrite-text"><a href="https://anudiptta-de.github.io/portfolio/"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is designed by <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://anudiptta-de.github.io/portfolio/" target="_blank">MR 17UEC095</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
            </div>
        </div></div>
</div>






</body>
</html>