<?PHP
$user="root";
$pass="";
$db="randikhana";
$link=mysql_connect('localhost',$user,$pass);
if(!$link)
die("unable to open database");
mysql_select_db($db) OR die("unable to open file");




$name=$_POST['a'];
$userid=$_POST['b'];
$email=$_POST['c'];
$password=$_POST['d'];
$confirmpassword=$_POST['e'];
$p="SELECT * FROM customersignup WHERE email='$email' ";
$result=mysql_query($p);

if($result)
{

if(mysql_num_rows($result)==0)


{
$p=mysql_query("insert into customersignup(name,userid,email,password,confirmpassword) values('$name','$userid','$email','$password','$confirmpassword')") or die("insert error");
header("location:animatedloginsignup11.html");
}
else 
{
echo"<script>
window.open('animatedloginsignup11.html');
</script>";
echo "Already registered email";
}
}
else

echo "query failed";
?>